import os
import json
from kaggle.api.kaggle_api_extended import KaggleApi

def download_kaggle_dataset():
    # Initialize the API
    api = KaggleApi()
    api.authenticate()
    
    # Create data directory if it doesn't exist
    os.makedirs('data', exist_ok=True)
    
    try:
        # Download the dataset
        api.dataset_download_files('udaymalviya/bank-loan-data', path='data', unzip=True)
        print("Dataset downloaded successfully!")
    except Exception as e:
        print(f"Error downloading dataset: {e}")

if __name__ == "__main__":
    download_kaggle_dataset()

import os
import getpass
import json

def setup_kaggle_credentials():
    print("\nTo set up Kaggle authentication, you'll need your Kaggle username and API key.")
    print("If you don't have an API key yet, follow these steps:")
    print("1. Go to https://www.kaggle.com/")
    print("2. Click on your profile picture in the top right corner")
    print("3. Click on 'Account'")
    print("4. Scroll down to the 'API' section")
    print("5. Click 'Create New API Token'")
    print("6. Download the kaggle.json file")
    print()
    
    # Get Kaggle credentials
    username = input("Enter your Kaggle username: ")
    key = getpass.getpass("Enter your Kaggle API key: ")
    
    # Create kaggle.json
    kaggle_json = {
        "username": username,
        "key": key
    }
    
    # Write to file
    with open(os.path.expanduser('~/.kaggle/kaggle.json'), 'w') as f:
        json.dump(kaggle_json, f)
    
    # Set proper permissions
    os.chmod(os.path.expanduser('~/.kaggle/kaggle.json'), 0o600)
    
    print("\nKaggle credentials have been successfully set up!")
    print("You can now download datasets from Kaggle.")

if __name__ == "__main__":
    setup_kaggle_credentials()

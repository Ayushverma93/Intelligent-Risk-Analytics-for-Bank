import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
import os

class DataProcessor:
    def __init__(self, data_path):
        self.data_path = data_path
        self.raw_data = None
        self.processed_data = None
        
    def load_data(self):
        """Load raw data from CSV file"""
        try:
            self.raw_data = pd.read_csv(self.data_path)
            return True
        except Exception as e:
            print(f"Error loading data: {e}")
            return False
    
    def clean_data(self):
        """Clean and preprocess the data"""
        if self.raw_data is None:
            return False
            
        # Handle missing values
        self.processed_data = self.raw_data.copy()
        
        # Fill missing values with appropriate methods
        numeric_cols = self.processed_data.select_dtypes(include=['float64', 'int64']).columns
        categorical_cols = self.processed_data.select_dtypes(include=['object']).columns
        
        # Fill numeric columns with median
        for col in numeric_cols:
            self.processed_data[col] = self.processed_data[col].fillna(self.processed_data[col].median())
            
        # Fill categorical columns with mode
        for col in categorical_cols:
            self.processed_data[col] = self.processed_data[col].fillna(self.processed_data[col].mode()[0])
            
        # Convert categorical variables to numeric
        self.processed_data = pd.get_dummies(self.processed_data, drop_first=True)
        
        # Standardize numeric features
        scaler = StandardScaler()
        self.processed_data[numeric_cols] = scaler.fit_transform(self.processed_data[numeric_cols])
        
        return True
    
    def save_processed_data(self, output_path):
        """Save processed data to CSV"""
        if self.processed_data is not None:
            self.processed_data.to_csv(output_path, index=False)
            return True
        return False
    
    def get_feature_importance(self, target_column):
        """Calculate feature importance using correlation"""
        if self.processed_data is not None:
            # Convert target column name to lowercase to match data
            target_column = target_column.lower()
            if target_column in self.processed_data.columns:
                correlations = self.processed_data.corr()[target_column].abs()
                return correlations.sort_values(ascending=False)
        return None

# Example usage
def main():
    processor = DataProcessor("data/loan_data.csv")
    if processor.load_data():
        if processor.clean_data():
            processor.save_processed_data("data/processed_loan_data.csv")
            feature_importance = processor.get_feature_importance("default")
            print("Feature Importance:")
            print(feature_importance)

if __name__ == "__main__":
    main()

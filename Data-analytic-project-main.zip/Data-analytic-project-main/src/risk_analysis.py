import numpy as np
import pandas as pd

# Load the data
def load_data():
    try:
        df = pd.read_csv('data/loan_data.csv')
        print(f"Loaded {len(df)} records")
        return df
    except Exception as e:
        print(f"Error loading data: {e}")
        return None

def explore_data(df):
    """Perform initial data exploration"""
    print("\nData Overview:")
    print(df.info())
    
    print("\nMissing Values:")
    print(df.isnull().sum())
    
    print("\nBasic Statistics:")
    print(df.describe())

def calculate_risk_metrics(df):
    """Calculate various risk metrics"""
    metrics = {}
    
    # Default rate
    metrics['default_rate'] = df['loan_status'].mean() * 100
    
    # Average loan amount
    metrics['avg_loan_amount'] = df['loan_amnt'].mean()
    
    # Calculate risk score based on multiple factors
    df['risk_score'] = (df['loan_percent_income'] * 100) + \
                     (df['cb_person_cred_hist_length'] / 10) + \
                     (df['loan_amnt'] / 1000) - \
                     (df['credit_score'] / 100)
    
    # Risk categories
    metrics['high_risk_pct'] = ((df['risk_score'] > 70) & (df['loan_status'] == 1)).mean() * 100
    metrics['medium_risk_pct'] = ((df['risk_score'] > 50) & (df['risk_score'] <= 70) & (df['loan_status'] == 1)).mean() * 100
    metrics['low_risk_pct'] = ((df['risk_score'] <= 50) & (df['loan_status'] == 1)).mean() * 100
    
    # Average loan-to-income ratio
    metrics['avg_loan_income_ratio'] = df['loan_percent_income'].mean() * 100
    
    # Calculate more metrics
    metrics['avg_credit_score'] = df['credit_score'].mean()
    metrics['avg_income'] = df['person_income'].mean()
    metrics['avg_age'] = df['person_age'].mean()
    
    # Employment experience metrics
    metrics['avg_emp_exp'] = df['person_emp_exp'].mean()
    metrics['high_emp_exp_pct'] = (df['person_emp_exp'] > 10).mean() * 100
    
    # Loan intent metrics
    loan_intent_groups = df.groupby('loan_intent')
    metrics['highest_default_intent'] = loan_intent_groups['loan_status'].mean().idxmax()
    metrics['highest_default_rate'] = loan_intent_groups['loan_status'].mean().max() * 100
    
    # Education level metrics
    education_groups = df.groupby('person_education')
    metrics['highest_default_education'] = education_groups['loan_status'].mean().idxmax()
    metrics['education_default_rate'] = education_groups['loan_status'].mean().max() * 100
    
    return metrics

def analyze_risk_patterns(df):
    """Analyze risk patterns using pandas"""
    print("\nRisk Pattern Analysis:")
    
    # 1. Group by loan status and analyze patterns
    loan_status_groups = df.groupby('loan_status')
    
    # Compare means for different groups
    print("\nComparison of Means by Loan Status:")
    print(loan_status_groups[['credit_score', 'person_income', 'loan_amnt', 'loan_percent_income']].mean())
    
    # Compare distributions using describe()
    print("\nDistribution Statistics by Loan Status:")
    print(loan_status_groups[['credit_score', 'person_income', 'loan_amnt']].describe())
    
    # 2. Calculate correlation matrix
    numeric_df = df.select_dtypes(include=[np.number])
    correlation_matrix = numeric_df.corr()
    
    print("\nCorrelation Matrix:")
    print(correlation_matrix)
    
    # Find most correlated features with loan status
    loan_status_correlations = correlation_matrix['loan_status'].abs().sort_values(ascending=False)
    print("\nMost Correlated Features with Loan Status:")
    print(loan_status_correlations)
    
    # 3. Analyze categorical variables
    print("\nCategorical Variable Analysis:")
    
    # Loan intent analysis
    print("\nLoan Intent Analysis:")
    loan_intent_groups = df.groupby('loan_intent')
    print("Default Rate by Loan Intent:")
    print(loan_intent_groups['loan_status'].mean())
    
    # Education level analysis
    print("\nEducation Level Analysis:")
    education_groups = df.groupby('person_education')
    print("Default Rate by Education Level:")
    print(education_groups['loan_status'].mean())
    
    # Gender analysis
    print("\nGender Analysis:")
    gender_groups = df.groupby('person_gender')
    print("Default Rate by Gender:")
    print(gender_groups['loan_status'].mean())
    
    # Home ownership analysis
    print("\nHome Ownership Analysis:")
    home_ownership_groups = df.groupby('person_home_ownership')
    print("Default Rate by Home Ownership:")
    print(home_ownership_groups['loan_status'].mean())
    
    # 4. Analyze age distribution
    print("\nAge Distribution Analysis:")
    age_bins = pd.cut(df['person_age'], bins=[20, 30, 40, 50, 60, 70, 80, 90, 100, 150])
    age_groups = df.groupby(age_bins)
    print("\nDefault Rate by Age Group:")
    print(age_groups['loan_status'].mean())
    
    # 5. Analyze income brackets
    print("\nIncome Bracket Analysis:")
    income_bins = pd.cut(df['person_income'], bins=[0, 20000, 40000, 60000, 80000, 100000, 200000, 500000, 1000000])
    income_groups = df.groupby(income_bins)
    print("\nDefault Rate by Income Bracket:")
    print(income_groups['loan_status'].mean())
    
    # 6. Analyze loan amount brackets
    print("\nLoan Amount Analysis:")
    loan_bins = pd.cut(df['loan_amnt'], bins=[0, 5000, 10000, 15000, 20000, 25000, 30000, 40000])
    loan_groups = df.groupby(loan_bins)
    print("\nDefault Rate by Loan Amount Bracket:")
    print(loan_groups['loan_status'].mean())
    
    # 7. Analyze credit score brackets
    print("\nCredit Score Analysis:")
    credit_bins = pd.cut(df['credit_score'], bins=[300, 500, 600, 650, 700, 750, 800, 850])
    credit_groups = df.groupby(credit_bins)
    print("\nDefault Rate by Credit Score Bracket:")
    print(credit_groups['loan_status'].mean())
    
    # 8. Analyze loan-to-income ratio
    print("\nLoan-to-Income Ratio Analysis:")
    ratio_bins = pd.cut(df['loan_percent_income'], bins=[0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0])
    ratio_groups = df.groupby(ratio_bins)
    print("\nDefault Rate by Loan-to-Income Ratio:")
    print(ratio_groups['loan_status'].mean())
    
    # 9. Cross-tab analysis
    print("\nCross-tab Analysis:")
    # Age and loan status
    print("\nAge Group vs Default Rate:")
    print(pd.crosstab(age_bins, df['loan_status'], normalize='index') * 100)
    
    # Income and loan status
    print("\nIncome Bracket vs Default Rate:")
    print(pd.crosstab(income_bins, df['loan_status'], normalize='index') * 100)
    
    # Credit score and loan status
    print("\nCredit Score Bracket vs Default Rate:")
    print(pd.crosstab(credit_bins, df['loan_status'], normalize='index') * 100)
    
    # Education and loan status
    print("\nEducation Level vs Default Rate:")
    print(pd.crosstab(df['person_education'], df['loan_status'], normalize='index') * 100)
    
    # Home ownership and loan status
    print("\nHome Ownership vs Default Rate:")
    print(pd.crosstab(df['person_home_ownership'], df['loan_status'], normalize='index') * 100)

def main():
    # Load data
    df = load_data()
    if df is None:
        return
    
    # Explore data
    explore_data(df)
    
    # Calculate risk metrics
    metrics = calculate_risk_metrics(df)
    print("\nRisk Metrics:")
    for metric, value in metrics.items():
        if isinstance(value, (int, float)):
            print(f"{metric}: {value:.2f}")
        else:
            print(f"{metric}: {value}")
    
    # Analyze risk patterns
    analyze_risk_patterns(df)

if __name__ == "__main__":
    main()
